# OWHS: the Open Workplace Health Standard

**v0.2 draft · early open specification · published for public review**

An open data standard for workplace health: sickness absence, return to work, occupational health, wellbeing measurement and benefit provision, defined once, in plain language and machine-readable schemas, private by design, free for anyone to implement. Built first for the UK, and for the millions of businesses everywhere that will never have a data team.

> "Currently, sickness absence is tracked inconsistently, and return-to-work outcomes are rarely measured."
> UK Government, Keep Britain Working programme, announcing the Workplace Health Intelligence Unit, July 2026

OWHS is an independent, open proposal for what standardised workplace-health data should look like at the level of an employer's records: anchored to the definitions the UK already trusts (ONS, HSE Management Standards, the statutory fit note, SSP), implementable by the smallest employer, and versioned so that when official definitions arrive they slot in rather than start over.

## What's here

| Path | Contents |
|---|---|
| `spec/` | The v0.2 specification draft (`OWHS-v0.2-draft.md`, composed from the sixteen schemas, the code-list registry and the v0.1 text by `tools/build_spec_v0_2.py`) and the v0.1 draft it supersedes: entity catalogue, per-field tables with privacy classes, profile mechanism, pseudonymisation design, conformance levels, and an honesty pass listing every disputable decision. Plus the ERD source. |
| `schemas/` | Versioned JSON Schemas (Draft 2020-12): sixteen v0.2 entity types and the three preserved v0.1 entity types; see the catalogue for exact identifiers, examples and validation scope. They reject undeclared properties and implement the documented structural constraints. They cannot detect identifiers or clinical content embedded in permitted string values, and do not implement all privacy-profile requirements. |
| `examples/` | A valid and a deliberately invalid instance per schema, with the validation report showing exactly which conformance errors the invalid ones raise. |
| `codelists/` | 27 independently versioned code lists (ONS absence reasons, fit-note adjustment categories, HSE-anchored construct domains and HSE Management Standards domains, the provisional safeguarding-category list, the benefit layer, the release category, and more) plus the registry. The registry names the file for every released version of a list; superseded versions are kept byte-for-byte under `codelists/archive/`. `absence-reason@0.2.0` carries the ten ONS 2025 reason categories and the separate non-disclosure response, with the crosswalk from the six-code v0.1.0 list under `codelists/mappings/`; the v0.1 schema stays pinned to 0.1.0. |
| `tools/` | The reference validator (Level 1, structural), `python tools/validate.py <schema> <instance>`; the measurement-bundle checker; the entity-graph checker for a supplied bundle of records (`python tools/check_entity_graph.py BUNDLE.json`, see `docs/entity-graph-validation-v0.2.md`); the generators and gates CI runs. |
| `site/` | The project site: plain-language pages, the instrument evidence registry (dataset v0.9.0, schema 0.7, grading rubric v1.6), the question bank, search. |
| `GOVERNANCE.md` | Stewardship, the progressive-governance model, licences, the change process. |
| `DECISIONS.md` | The public decision log, running since before release. |

## Check a file in your browser

[openworkplacehealth.org/check/](https://openworkplacehealth.org/check/) checks one v0.2 record, or an entity-graph bundle, without installing anything. It runs `tools/validate.py` and `tools/check_entity_graph.py` from this repository, unchanged, in Python compiled to WebAssembly (Pyodide 314.0.7, jsonschema 4.26.0), so a verdict there is the reference validator's verdict, and it explains each failure with the field, the rule and the specification's own wording.

- **Nothing leaves the browser.** The page fetches only its own files from the site (about 14 MB, uncompressed, the first time Check is pressed), makes no request while it checks, carries no visit counter, and declares a Content-Security-Policy that confines it to its own origin. Everything it loads is vendored under `site/check/vendor/`, with sources, hashes and licences in `site/check/vendor/MANIFEST.json`.
- **Same verdicts.** `python tools/check_browser_checker.py` runs every file in `examples/v0.2/` and every bundle case through the command-line tools and through the page in headless Chrome, and fails on any difference in verdict or in the rules reported. It also confirms that the page makes no request while checking and keeps working offline. It needs a Chrome or Chromium binary and nothing else beyond `requirements.txt`.
- **Honest scope.** A pass is structurally conformant at Level 1. The page does not check Level 2 or Level 3.

The page and its data are generated: `python tools/build_checker.py` then `python tools/stamp_canonical.py`; `--check` compares the committed files with a fresh build and verifies every vendored file against its pinned hash.

## The privacy profile, in one paragraph

OWHS prohibits direct identifiers in its payloads. The current schemas reject undeclared properties, but identifiers inside permitted string values remain a producer obligation. Employer-visible aggregates have a floor of five respondents, or ten for severe-distress measures. The narrowly defined `individual-employer` fields are exempt from these floors where an independent legal basis permits disclosure. Individual instrument results are not employer-visible, and safeguarding-category signals are excluded from employer-visible output at every group size. Aggregates must carry completion and suppression metadata. These are conformance requirements: the reference validator currently implements Level 1 structural checks, including formats and named date-order rules, and does not verify Level 2 or Level 3.

## Status

> **Status: early open specification.**
> OWHS was created by [Zak Fenton](https://www.linkedin.com/in/zak-fenton-a433624b/) and is currently stewarded by Alltoogether. Its specification, schemas and supporting materials are published under permissive licences and are open to inspect, use, challenge and improve. If OWHS earns independent use and recurring contribution, its governance will move to a multi-stakeholder structure so that no single commercial organisation controls its future.

Alltoogether develops commercial products that may implement OWHS. The standard does not require use of any Alltoogether product, and the project publishes its contribution, decision and change processes openly.

This is a v0.x specification, published to be improved and, where national definitions emerge, to be overwritten gracefully (a `whiu:` namespace is reserved for the Workplace Health Intelligence Unit's future definitions). See the honesty pass in `spec/`: the decisions reasonable people would dispute, the assumptions government could contradict, and the questions that need governance rather than engineering.

## Licences

Specification text and documentation: **CC-BY 4.0**. Schemas, code lists, examples and tooling: **Apache 2.0**. Anyone may implement OWHS in commercial or non-commercial products without permission, payment or notification.

## The instrument registry, and its current limit

The instrument registry is the open synthesis of the published evidence on instruments used to measure workplace health and wellbeing. For every instrument it records what it measures, how well, in which populations and languages, and on what licence terms, drawn from the literature and existing systematic reviews, every claim cited, every grade conservative. It is maintained, machine-readable and free to use, so that nobody choosing, building, licensing or reviewing a workplace measure has to reassemble the field's evidence themselves.

It grades 27 instruments, stage one of the field, across eight psychometric evidence properties in the matrix, with a ninth (populations, languages and norms) on each record, licence class verified against archived steward pages, and single-item measures linked in the data to the multi-item instruments they have been validated against. All grades were assigned by one rater employed by the steward, under the rules published as rubric v1.6 (`site/instrument-registry/RUBRIC-v1.6.md`; indirectness is defined by population type, never by country; a High grade needs two cited studies with a sample size and a statistic of the property graded). Grades and statuses are frozen from first publication until two named psychometric raters who are not steward employees have joined. AI assists retrieval, screening, extraction and drafting; it never assigns a grade, and nothing it produces reaches the dataset except through a pull request a human merges.

## Get involved

Issues and RFCs are open to anyone once this repository is public. The ask is deliberately small: find the flaw, suggest a missing field or definition, or test-map one of your existing exports and report where it breaks. You do not need to endorse the standard or join anything. Substantive contributions are reviewed in the next published maintenance cycle. Every issue template asks for a declaration of any financial or professional interest in what the contribution touches; an interest does not disqualify a contribution, an undeclared one does. The registry's most specific ask is for independent raters: see `site/contribute.html`. See `GOVERNANCE.md` for the progressive-governance model and the evidence-gated path to multi-stakeholder stewardship.

Contact: hello@openworkplacehealth.org · https://openworkplacehealth.org

---

*Stewarded by All Toogether Ltd (Alltoogether), Manchester, UK. See GOVERNANCE.md for why that's stated plainly and how governance evolves.*
